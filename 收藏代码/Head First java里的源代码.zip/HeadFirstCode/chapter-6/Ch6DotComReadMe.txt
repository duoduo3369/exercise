DotComBust read me    Chapter 6

1) Put all three source files:

  DotCom.java
  DotComBust.java
  GameHelper.java

into the same directory.

2) Compile them all.

3) Type 'java DotComBust' to run the game.

Note:  There are several lines commented out in the GameHelper.java file.  If you want to see a little about how that class works you can 'uncomment' those lines, recompile and rerun.