ReadMe for ServiceServer

You will need at least three terminals to run this service.  Start them in this order:

1 - rmiregistry

2 - java ServiceServerImpl

3 - java ServiceBrowser