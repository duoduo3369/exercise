package headfirst.factory.pizzaaf;

public interface Clams {
	public String toString();
}
