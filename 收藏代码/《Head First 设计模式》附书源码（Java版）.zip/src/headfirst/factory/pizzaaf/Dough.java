package headfirst.factory.pizzaaf;

public interface Dough {
	public String toString();
}
