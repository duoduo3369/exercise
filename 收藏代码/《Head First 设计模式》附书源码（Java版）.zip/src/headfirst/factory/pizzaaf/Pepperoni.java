package headfirst.factory.pizzaaf;

public interface Pepperoni {
	public String toString();
}
