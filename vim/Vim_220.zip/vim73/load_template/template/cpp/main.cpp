/*=============================================================================
#  Author:          
#  Email:           
#  FileName:        
#  Version:         
#  LastChange:      
#  Description:     
#  History:         
=============================================================================*/
#include <iostream>
#include <string>
#include <vector>
#include <map>
using namespace std;
int main(int argc,char* argv[])
{
	TEMPLATE_CURSOR
	return 0;
}
