package javathreads.examples.ch08.example1;

public interface CharacterListener {
    public void newCharacter(CharacterEvent ce);
}
