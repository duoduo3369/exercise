package javathreads.examples.ch05;

public interface CharacterListener {
    public void newCharacter(CharacterEvent ce);
}
