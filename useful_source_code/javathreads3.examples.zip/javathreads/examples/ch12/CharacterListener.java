package javathreads.examples.ch12;

public interface CharacterListener {
    public void newCharacter(CharacterEvent ce);
}
