package javathreads.examples.ch04;

public interface CharacterListener {
    public void newCharacter(CharacterEvent ce);
}
